package com.example.tarefas_gerenciador_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TarefasGerenciadorJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
