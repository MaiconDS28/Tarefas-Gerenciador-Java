package com.example.tarefas_gerenciador_java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TarefasGerenciadorJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TarefasGerenciadorJavaApplication.class, args);
	}

}
